@extends('layouts.aac')

@section('content')
    @include($body)
@endsection