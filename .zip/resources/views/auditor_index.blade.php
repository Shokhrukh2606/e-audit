@extends('layouts.auditor')

@section('content')
    @include($body)
@endsection