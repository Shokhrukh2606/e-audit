@extends('layouts.agent')

@section('content')
    @include($body)
@endsection