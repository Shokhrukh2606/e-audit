@extends('layouts.customer')

@section('content')
    @include($body)
@endsection