@extends('layouts.admin')

@section('content')
    @include($body)
@endsection