<h2><?php echo e("У вас есть ".Auth::user()->agent_conclusions->count()." заключены"); ?></h2>
<div class="card">
	<div class="card-header">
      <h1 class="card-title">Заключении</h1>
    <a class="btn btn-sm btn-success" href="<?php echo e(route('agent.create_conclusion')); ?>"><?php echo e(__('custom.create')); ?></a>
	</div>
	<div class="card-body">
        <table class="table tablesorter">
            <tr>
				<th><?php echo e(__('front.template_num')); ?></th>
                <th><?php echo e(__('front.use_cases')); ?></th>
                <th><?php echo e(__('front.fio')); ?></th>
                <th><?php echo e(__('front.aduit_comp_name')); ?></th>
                <th><?php echo e(__('front.audit_comp_direc_name')); ?></th>
                <th><?php echo e(__('front.audit_comp_inn')); ?></th>
            </tr>
            <?php $__currentLoopData = $conclusions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->cust_info->template->standart_num); ?></td>
                    <td>
                        
                        <?php $__currentLoopData = $item->cust_info->use_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <span><?php echo e(json_decode($uc->title)->ru); ?></span> | 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <td><?php echo e(getUserName($item->agent_id)); ?></td>
                    <td><?php echo e($item->audit_comp_name); ?></td>
                    <td><?php echo e($item->audit_comp_director_name); ?></td>
                    <td><?php echo e($item->audit_comp_inn); ?></td>
                    <td><a href="<?php echo e(route('agent.view_conclusion_open', $item->id)); ?>">More</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        
        <table class="table tablesorter">
			<thead>
				<th>ID</th>
				<th><?php echo e(__('front.customer')); ?></th>
				<th><?php echo e(__('front.auditor')); ?></th>
				<th><?php echo e(__('front.agent')); ?></th>
				<th><?php echo e(__('front.template_num')); ?></th>
				<th><?php echo e(__('front.actions')); ?></th>
			</thead>
			<tbody>
				<tr>
					<?php $__currentLoopData = $conclusions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conclusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($conclusion->id); ?></td>
						<td>
							<?php echo e($conclusion->customer->name??'No'); ?>

							<?php echo e($conclusion->customer->surname??'Customer'); ?>

						</td>
						<td>
							<?php echo e($conclusion->auditor->name??'No'); ?>

							<?php echo e($conclusion->auditor->surname??'Auditor'); ?>

						</td>
						<td>
							<?php echo e($conclusion->agent->name??'No'); ?>

							<?php echo e($conclusion->agent->surname??'Agent'); ?>

						</td>
						<td><?php echo e($conclusion->cust_info->template->standart_num); ?></td>
						<td><a href="#">View</a></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
			</tbody>
		</table>
	</div>
  </div>
  
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Agent/list_conclusions.blade.php ENDPATH**/ ?>