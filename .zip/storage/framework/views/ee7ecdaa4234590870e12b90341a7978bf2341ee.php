<form action="<?php echo e(route('admin.view_user', ['id'=>$user->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label><?php echo e(__('front.username')); ?></label>
    <input class="form-control" type="text" name="user[name]" value="<?php echo e($user->name); ?>"><br>

    <label><?php echo e(__('front.last_name')); ?></label>
    <input class="form-control" type="text" name="user[surname]" value="<?php echo e($user->surname); ?>"><br>

    <label><?php echo e(__('front.middle_name')); ?></label>
    <input class="form-control" type="text" name="user[patronymic]" value="<?php echo e($user->patronymic); ?>"><br>

    <label><?php echo e(__('front.phone')); ?></label>
    <input class="form-control" type="text" name="user[phone]" value="<?php echo e($user->phone); ?>"><br>

    <label><?php echo e(__('front.p_ser')); ?></label>
    <input class="form-control" type="text" name="user[passport_number]" value="<?php echo e($user->passport_number); ?>"><br>

    <label><?php echo e(__('front.cer_number')); ?></label>
    <input class="form-control" type="text" name="user[cert_number]" value="<?php echo e($user->cert_number); ?>"><br>

    <label><?php echo e(__('front.cer_date')); ?></label>
    <input class="form-control" type="date" name="user[cert_date]" value="<?php echo e($user->cert_date); ?>"><br>

    <label><?php echo e(__('front.region')); ?></label>
    <input class="form-control" type="text" name="user[region]" value="<?php echo e($user->region); ?>"><br>

    <label><?php echo e(__('front.district')); ?></label>
    <input class="form-control" type="text" name="user[district]" value="<?php echo e($user->district); ?>"><br>

    <label><?php echo e(__('front.address_permanent')); ?></label>
    <input class="form-control" type="text" name="user[address]" value="<?php echo e($user->address); ?>"><br>

    <label><?php echo e(__('front.password')); ?></label>
    <input class="form-control" type="text" name="user[password]"><br>

    <label><?php echo e(__('front.role')); ?></label>
    <select class="form-control" name="user[group_id]" }}>
        <option value=""><?php echo e(__('front.role')); ?></option>
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>" <?php echo e($user->group_id == $item->id ? 'selected' : ''); ?>>
            <?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <button class="btn btn-sm btn-success" type="submit"><?php echo e(__('front.save')); ?></button>
</form><?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Admin/view_user.blade.php ENDPATH**/ ?>