<div class="card">
    <div class="card-header">
        <h1 class="card-title">Закаы</h1>
    </div>
    <div class="card-body">
        <table class="table tablesorter">
            <thead>
                <th>ID</th>
                <th><?php echo e(__('front.customer')); ?></th>
                <th><?php echo e(__('front.auditor')); ?></th>
                <th><?php echo e(__('front.template_num')); ?></th>
                <th><?php echo e(__('front.status')); ?></th>
                <th><?php echo e(__('front.created_at')); ?></th>
                <th><?php echo e(__('custom.show')); ?></th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->customer->name); ?></td>
                        <td><?php echo e($order->auditor->name ?? 'No one yet'); ?></td>
                        <td><?php echo e($order->cust_info->template->standart_num); ?></td>
                        <td><?php echo e(__('front.'.$order->status)); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td><a href="<?php echo e(route('admin.order', $order->id)); ?>"><?php echo e(__('custom.show')); ?></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Admin/list_orders.blade.php ENDPATH**/ ?>