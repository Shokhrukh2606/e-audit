<form action="<?php echo e(route("admin.create_user")); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
    <label>First Name</label>
<input type="text" name="user[name]" value="<?php echo e($user->name); ?>"><br>
    
    <label>Surname</label>
    <input type="text" name="user[surname]" value="<?php echo e($user->surname); ?>"><br>
    
    <label>Patronymic</label>
    <input type="text" name="user[patronymic]" value="<?php echo e($user->patronymic); ?>"><br>
    
    <label>Phone</label>
    <input type="text" name="user[phone]" value="<?php echo e($user->phone); ?>"><br>

    <label>Passport Serial Number</label>
    <input type="text" name="user[passport_number]" value="<?php echo e($user->passport_number); ?>"><br>

    <label>Certificate number</label>
    <input type="text" name="user[cert_number]" value="<?php echo e($user->cert_number); ?>"><br>

    <label>Certificate date</label>
    <input type="date" name="user[cert_date]" value="<?php echo e($user->cert_date); ?>"><br>

    <label>Region</label>
    <input type="text" name="user[region]" value="<?php echo e($user->region); ?>"><br>
    
    <label>District</label>
    <input type="text" name="user[district]" value="<?php echo e($user->district); ?>"><br>

    <label>Address</label>
    <input type="text" name="user[address]" value="<?php echo e($user->address); ?>"><br>

    <label>Password</label>
    <input type="text" name="user[password]"><br>

    <label>Role</label>
    <select name="user[group_id]"}}>
        <option value="">Role</option>
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($user->group_id == $item->id ? 'selected' : ''); ?>>
                <?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <button type="submit">Submit</button>
</form><?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Admin/one_user.blade.php ENDPATH**/ ?>