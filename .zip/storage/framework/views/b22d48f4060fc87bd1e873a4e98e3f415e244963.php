<div class="card">
    <div class="card-header">
        <h3 class="card-title">My Orders</h3>
    </div>
    <div class="card-body">
		<table class="table tablesorter">
			<thead>
				<th>ID</th>
			<th><?php echo e(__('front.customer')); ?></th>
				<th><?php echo e(__('front.template')); ?></th>
				<th><?php echo e(__('front.use_cases')); ?></th>
				<th><?php echo e(__('front.actions')); ?></th>
			</thead>
			<tbody>
		
				<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<td><?php echo e($order->id); ?></td>
				<td><?php echo e($order->customer->name); ?></td>
				<td><?php echo e($order->cust_info->template_id); ?></td>
				<td>
					<?php $__currentLoopData = $order->cust_info->use_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <span><?php echo e(json_decode($uc->title)->ru); ?></span> | 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				<td>
					<a href="<?php echo e(route('auditor.view_order', $order->id)); ?>"><?php echo e(__('custom.show')); ?></a>
				</td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
    </div>
</div>

<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Auditor/list_orders.blade.php ENDPATH**/ ?>