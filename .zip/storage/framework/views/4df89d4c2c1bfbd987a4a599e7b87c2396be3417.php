<form action="<?php echo e(route('agent.create_conclusion')); ?>">
	<div>
		<?php echo e(__('front.select_temp')); ?>:
		<select class="form-control" name="template_id" required onchange="alter_use_cases(this)">
			<?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($template->id); ?>"><?php echo e($template->standart_num); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	<div>
		<?php echo e(__('front.select_use_case')); ?>:
		<div id="use_cases">
			<?php $__currentLoopData = $use_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use_case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div data-value="<?php echo e($use_case->id); ?>" data-temp_id="<?php echo e($use_case->template_id); ?>">
				<input type="checkbox" class="form-control" name="use_cases[<?php echo e($use_case->id); ?>]" class="uc">
				<?php echo e(json_decode($use_case->title)->uz); ?>

			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<button class="btn btn-success" type="submit"><?php echo e(__('front.continue')); ?></button>
</form>
<script>
	function alter_use_cases(elem){
		let value=elem.value;
		let use_cases=document.getElementById("use_cases").children;
		for(use_case_cont of use_cases){
			use_case_cont.style.display="";
			// input is the zero child
			use_case_cont.children[0].checked=false;
			if(use_case_cont.dataset.temp_id!==value){
				use_case_cont.style.display="none";
			}
		}
	}
</script><?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Agent/select_template.blade.php ENDPATH**/ ?>