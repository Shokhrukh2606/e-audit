<h2><?php echo e(Auth::user()->funds); ?></h2>
<a href="<?php echo e(route('aac.add_funds')); ?>"><?php echo e(__('front.add_funds')); ?></a>
<table style="width:100%">
    <tr>
    <th><?php echo e(__('front.amount')); ?></th>
        <th><?php echo e(__('front.price')); ?></th>
    <th><?php echo e(__('front.transferred_date')); ?></th>
    </tr>
    <?php $__currentLoopData = Auth::user()->oldFunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->payment_sys); ?></td>
            <td><?php echo e($item->amount); ?></td>
            <td><?php echo e($item->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/AAC/checkfunds.blade.php ENDPATH**/ ?>