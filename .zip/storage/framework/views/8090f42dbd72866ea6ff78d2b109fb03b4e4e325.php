<form action="/admin/list_users" class="row mb-3" id="filterer">
    &nbsp;
    <div class="col">
        <label><?php echo e(__('front.fio')); ?></label>
        <input class="form-control" type="text" value="<?php echo e(request()->input('filter.name')); ?>" name="filter[name]">
    </div>
    <div class="col">
        <label><?php echo e(__('front.role')); ?></label>
        <select class="form-control" name="filter[group_id]">
        <option value=""><?php echo e(__('front.role')); ?></option>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"
                    <?php echo e(request()->input('filter.group_id') == $item->id ? 'selected' : ''); ?>>
                    <?php echo e($item->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col">
    <label><?php echo e(__('front.phone')); ?></label>
        <input class="form-control" type="phone" type="text" name="filter[phone]"
            value="<?php echo e(request()->input('filter.phone')); ?>">
    </div>
    <div class="col">
        <label><?php echo e(__('front.inn')); ?></label>
        <input class="form-control" type="number" name="filter[inn]" value="<?php echo e(request()->input('filter.inn')); ?>">
    </div>
    <button class="btn btn-sm btn-success col-1 mt-auto" type="submit"><?php echo e(__('front.search')); ?></button>
</form>

<div class="card">
    <div class="card-header">
        <h1 class="card-title">Пользователи
        </h1>
        <a class="btn btn-sm btn-info" href="<?php echo e(route('admin.create_user')); ?>"><?php echo e(__('custom.create')); ?></a>
    </div>
    <div class="card-body">
        <table class="table tablesorter">
            <thead>
                <th>ID</th>
                <th><?php echo e(__('front.fio')); ?></th>
                <th><?php echo e(__('front.funds')); ?></th>
                <th><?php echo e(__('front.role')); ?></th>
                <th><?php echo e(__('front.phone')); ?></th>
                <th><?php echo e(__('front.inn')); ?></th>
                <th><?php echo e(__('custom.show')); ?></th>
            </thead>
            </tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td><?php echo e($user->funds); ?></td>
                    <td><?php echo e($user->group->name); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->inn); ?></td>
                    <td><a href="<?php echo e(route('admin.view_user', $user->id)); ?>"><?php echo e(__('custom.show')); ?></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Admin/list_users.blade.php ENDPATH**/ ?>