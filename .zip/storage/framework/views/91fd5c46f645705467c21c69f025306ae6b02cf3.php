

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($body, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OUR COMPANY\e-audit\resources\views/customer_index.blade.php ENDPATH**/ ?>