<div class="card">
    <div class="card-header">
        <h1 class="card-title">Заключении</h1>
    </div>
    <div class="card-body">
        <table class="table tablesorter">
            <thead>
                <th>ID</th>
                <th><?php echo e(__('front.customer')); ?></th>
                <th><?php echo e(__('front.auditor')); ?></th>
                <th><?php echo e(__('front.agent')); ?></th>
                <th><?php echo e(__('front.template_num')); ?></th>
                <th><?php echo e(__('custom.show')); ?></th>
            </thead>
            <tbody>
                <tr>
                    <?php $__currentLoopData = $conclusions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conclusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($conclusion->id); ?></td>
                        <td>
                            <?php echo e($conclusion->customer->name ?? 'No'); ?>

                            <?php echo e($conclusion->customer->surname ?? 'Customer'); ?>

                        </td>
                        <td>
                            <?php echo e($conclusion->auditor->name ?? 'No'); ?>

                            <?php echo e($conclusion->auditor->surname ?? 'Auditor'); ?>

                        </td>
                        <td>
                            <?php echo e($conclusion->agent->name ?? 'No'); ?>

                            <?php echo e($conclusion->agent->surname ?? 'Agent'); ?>

                        </td>
                        <td><?php echo e($conclusion->cust_info->template->standart_num); ?></td>
                        <td><a href="#"><?php echo e(__('custom.show')); ?></a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Admin/list_conclusions.blade.php ENDPATH**/ ?>