<div class="card">
    <div class="card-header">
        <h3><?php echo e(__('front.my_orders')); ?></h3>
        <a class="btn btn-sm btn-success" href="<?php echo e(route('customer.create_order')); ?>"><?php echo e(__('custom.create')); ?></a>
    </div>
    <div class="card-body">
        <table class="table tablesorter">
            <thead>
                <th>ID</th>
                <th><?php echo e(__('front.template_num')); ?></th>
                <th><?php echo e(__('front.use_cases')); ?></th>
                <th><?php echo e(__('front.date')); ?></th>
                <th><?php echo e(__('custom.show')); ?></th>
                <th><?php echo e(__('custom.show_conclusion')); ?></th>
                <th><?php echo e(__('custom.pay')); ?></th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->cust_info->template->standart_num); ?></td>
                        <td>
                            
                            <?php $__currentLoopData = $order->cust_info->use_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e(json_decode($uc->title)->ru); ?></span> |
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td>
                        <a href="<?php echo e(route('customer.order_view', $order->id)); ?>"><?php echo e(__('custom.show')); ?></a>
                        </td>
                        <td>
                            <?php if($order->cust_info->conclusion->id ?? false): ?>
                                <a href="<?php echo e(route('customer.conclusion', $order->cust_info->conclusion->id)); ?>">
                                    <?php echo e(__('custom.show_conclusion')); ?>

                                </a>
                            <?php else: ?>
                                <?php echo e(__('custom.conclusion_not_written')); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($order->cust_info->conclusion->id ?? false): ?>
                                <a href="<?php echo e(route('customer.pay', $order->cust_info->conclusion->id)); ?>">
                                    <?php echo e(__('custom.accept_pay')); ?>

                                </a>
                            <?php else: ?>
                                <?php echo e(__('custom.conclusion_not_written')); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Customer/list_orders.blade.php ENDPATH**/ ?>