<?php
$not_iterated=['id', 'customer_id', 'auditor_id',"conclusion_id","order_id", "template_id", "custom_fields"];
?>
<h2><?php echo e(__('front.order')); ?> <?php echo e($order->id); ?></h2>
<?php echo e(__('front.status')); ?>: <?php echo e(__('front.' . $order->status)); ?> <br>
<?php echo e(__('front.details')); ?>: <br>

<h3><?php echo e(__('front.order_info')); ?></h3>
<ul>
    <li><?php echo e(__('front.template_num')); ?>:<?php echo e($order->cust_info->template->standart_num); ?></li>
    <li><?php echo e(__('front.use_cases')); ?>:
        <?php $__currentLoopData = $order->cust_info->use_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span><?php echo e(json_decode($uc->title)->ru); ?></span> |
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </li>
    <?php $__currentLoopData = $order->getAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(in_array($key, $not_iterated, TRUE)) continue; ?>
        <li><?php echo e(__('front.' . $key)); ?>:<?php echo e($value); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<h3>Customer info</h3>
<ul>
    <?php $__currentLoopData = $order->cust_info->getAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(in_array($key, $not_iterated, TRUE)) continue; ?>
        <li><?php echo e(__('front.' . $key)); ?>:<?php echo e($value); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php
    // get custom fields array
    $custom_fields=json_decode($order->cust_info->custom_fields??"[]");
    ?>
    

    <?php $__currentLoopData = custom_fields($order->cust_info->template_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li>
            <?php echo e($field->label->ru); ?> :
            <?php if(!isset($custom_fields->{$field->name})): ?>
                Nothing yet
                <?php continue; ?>
            <?php endif; ?>
            <?php if($field->type == 'file'): ?>
                <a href="<?php echo e(route('file') . '?path=' . $custom_fields->{$field->name}); ?>" target="blank">
                    View
                </a>
            <?php else: ?>
                <?php echo e($custom_fields->{$field->name}); ?>

            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php if($order->status == 'open'): ?>
    <form action="<?php echo e(route('admin.assign_order', $order->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <select name="auditor_id">	
            <?php $__currentLoopData = $auditors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auditor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($auditor->id); ?>">
                    <?php echo e($auditor->name); ?> <?php echo e($auditor->surname); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-sm btn-success"><?php echo e(__('front.assign')); ?></button>
    </form>
<?php endif; ?>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Admin/view_order.blade.php ENDPATH**/ ?>