<form action="<?php echo e(route('customer.create_order')); ?>" method="POST" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="cust_info[template_id]" value="<?php echo e($template_id); ?>">
	<?php $__currentLoopData = $use_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use_case=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<input class="form-control" type="hidden" name="ciucm[<?php echo e($use_case); ?>]" value="<?php echo e($use_case); ?>">
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div>
	<label><?php echo e(__('front.lang')); ?></label>
		<select class="form-control" name="cust_info[lang]">
			<option value="uz"><?php echo e(__('front.oz')); ?></option>
			<option value="ru"><?php echo e(__('front.ru')); ?></option>
		</select>
	</div>
	<div>
	<label><?php echo e(__('front.phone')); ?></label>
		<input class="form-control" type="text" maxlength="13" name="order[phone]">
	</div>
	<div>
		<label><?php echo e(__('front.address')); ?></label>
		<input class="form-control" type="text" name="order[address_to_deliver]">
	</div>
	<div>
		<label><?php echo e(__('front.custom_comp_reg_num')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_gov_reg_num]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_reg_num_date')); ?></label>
		<input class="form-control" type="date" name="cust_info[cust_comp_gov_reg_date]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_address')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_address]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_bank')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_bank_name]">
	</div>
	<div>
		<label><?php echo e(__('front.custom_comp_bank_account')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_bank_acc]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_bank_mfo')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_bank_mfo]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_inn')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_inn]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_oked')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_oked]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_director_name')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_director_name]">
	</div>
	<div>
	<label><?php echo e(__('front.custom_comp_activity')); ?></label>
		<input class="form-control" type="text" name="cust_info[cust_comp_activity]">
	</div>
	<div>
		<?php
			$dom = new DOMDocument('1.0');
		?>
			<?php $__currentLoopData = custom_fields($template_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
				$div= $dom->createElement("div");
				$dom->appendChild($div);

				$label = $dom->createElement("label", $field->label->uz.":");
				$div->appendChild($label);
				
				$input = $dom->createElement($field->tag);
				
				$attr = $dom->createAttribute('type');
				$attr->value = $field->type;
				$input->appendChild($attr);

				$attr = $dom->createAttribute('name');
				$attr->value = "custom[$field->name]";
				$input->appendChild($attr);
				
				$div->appendChild($input);

				?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?=$dom->saveHTML()?>
	</div>
<button class="btn btn-sm btn-success" type="submit"><?php echo e(__('custom.create')); ?></button>
</form><?php /**PATH D:\OUR COMPANY\e-audit\resources\views/Customer/create_order.blade.php ENDPATH**/ ?>