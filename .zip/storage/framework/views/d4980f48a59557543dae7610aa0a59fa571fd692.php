<style>
    .d-none {
        display: none;
    }

</style>
<?php if($errors->any()): ?>
  <div class="alert alert-danger">
     <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
  </div>
<?php endif; ?>
<a href="#" class="navigator" data-id="user"><?php echo e(__('auth.user')); ?></a>
<a href="#" class="navigator" data-id="agent"><?php echo e(__('auth.agent')); ?></a>
<div class="user d-none" id="user">
    <h1><?php echo e(__("auth.Register User")); ?></h1>
    <form method="POST" action="<?php echo e(route('reg_cust')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label><?php echo e(__("auth.Name")); ?></label>
            <input type="text" name="name">
        </div>
        <div>
            <label><?php echo e(__("auth.Surname")); ?></label>
            <input type="text" name="surname">
        </div>
        <div>
            <label><?php echo e(__("auth.Patronymic")); ?></label>
            <input type="text" name="patronymic">
        </div>
        <label><?php echo e(__("auth.Phone number")); ?></label>
        <input type="text" name="phone">
        <div>
            <label><?php echo e(__("auth.Password")); ?></label>
            <input type="text" name="password">
        </div>
        <button type="submit"><?php echo e(__("auth.Register")); ?></button>
    </form>
</div>


<div class="agent d-none" id="agent">
    <h1><?php echo e(__("auth.Register Agent")); ?></h1>
    <form method="POST" action="<?php echo e(route('reg_agent')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label><?php echo e(__("auth.Name")); ?></label>
            <input type="text" name="name">
        </div>
        <div>
            <label><?php echo e(__("auth.Surname")); ?></label>
            <input type="text" name="surname">
        </div>
        <div>
            <label><?php echo e(__("auth.Patronymic")); ?></label>
            <input type="text" name="patronymic">
        </div>
        <div>
            <label><?php echo e(__("auth.Phone number")); ?></label>
            <input type="text" name="phone">
        </div>
        <div>
            <label><?php echo e(__("auth.Passport Number")); ?></label>
            <input type="text" maxlength="9" name="passport_number">
        </div>
        <div>
            <label><?php echo e(__("auth.Passport Copy")); ?></label>
            <input type="file" name="passport_copy">
        </div>
        <div>
            <label><?php echo e(__("auth.Inn")); ?></label>
            <input type="text" maxlength="9" name="inn">
        </div>
        <div>
            <label><?php echo e(__("auth.Certificate Number")); ?></label>
            <input type="text" name="cert_number">
        </div>
        <div>
            <label><?php echo e(__("auth.Certificate Date")); ?></label>
            <input type="date" name="cert_date">
        </div>
        <div>
            <label><?php echo e(__("auth.Region")); ?></label>
            <input type="text" name="region">
        </div>
        <div>
            <label><?php echo e(__("auth.District")); ?></label>
            <input type="text" name="district">
        </div>
        <div>
            <label><?php echo e(__("auth.Address")); ?></label>
            <input type="text" name="address">
        </div>
        <div>
            <label><?php echo e(__("auth.Password")); ?></label>
            <input type="text" name="password">
        </div>
        <div>
            <label><?php echo e(__("auth.I agree")); ?></label>
            <input type="checkbox">
        </div>

        <button type="submit"><?php echo e(__("auth.Register")); ?></button>
    </form>
</div>


<script>
var navigators=document.getElementsByClassName("navigator")
for(var i = 0; i < navigators.length; i++) {
  (function(index) {
    navigators[index].addEventListener("click", function(e) {
		e.preventDefault()
	    if(index==0){
			document.getElementById("user").style.display="block"
			document.getElementById("agent").style.display="none"
		}else{
			document.getElementById("user").style.display="none"
			document.getElementById("agent").style.display="block"
		}
     })
  })(i);
}

</script>
<?php /**PATH D:\OUR COMPANY\e-audit\resources\views/register/show.blade.php ENDPATH**/ ?>